OK = 0
USER_ERR = 1  # validation / bad args / misuse
IO_ERR = 2  # filesystem / parse / not found
INTERNAL = 3  # unexpected exception
