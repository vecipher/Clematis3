Scheduler core lives at clematis/engine/scheduler.py. clematis/scheduler.py is a compatibility shim.
